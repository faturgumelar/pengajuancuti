# Aplikasi Pengajuan Cuti

Aplikasi ini menggunakan CI 4 dan database MySQL.
Aplikasi ini ditunjukan untuk memenuhi challenge dari jabar coding camp yang diberikan oleh mitra PT Cybers Blitz Nusantara.

Aplikasi ini memiliki 3 role yaitu karyawan, manager, dan senior manager.

Seorang karyawan dapat mengajukan cuti yang diberikan kepada secara berurutan dari manager hingga level manager. Pengajuan Cuti dianggap disetujui jika di approve oleh seorang senior manager.

# Pengujian real Aplikasi Pengajuan Cuti

link : [aplikasi-pengajuan-cutti](https://umarsahid.my.id/portfolio/aplikasi-pengajuan-cuti/)

User Test

- Email : hendarwijaya@mail.com as karyawan
- Email : indahlestari@mail.com as karyawan
- Email : ekagustian@mail.com as manager
- Email : adamasetiawan@mail.com as senior manager

Password All User : 123
